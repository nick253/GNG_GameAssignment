sonaKiS's Factory Model : QUAD COPTER
(http://sonakis.blogspot.kr/)


It is a QuadCopter that can be used for hobby or for military use.
You can apply the animation to the propeller of four independent.
Body texture contains 2.
4 Gimp Templete.

Tris : 21871
Texture : 1024 px X 1024 px X 5

Body
 - T_QuadCopter_Body.png = Dark and Red
 - T_QuadCopter_Body_2.png = Military
Camera
 - T_QuadCopter_Carmera
Frame
 - T_QuadCopter_Frame
Propeller
 - T_QuadCopter_Prop



